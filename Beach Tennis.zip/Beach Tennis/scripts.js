// TOGGLE BUTTON MOBILE

const toggleButton = document.getElementById('toggle-button');
const drawer = document.getElementById('drawer');
const main = document.getElementById('main');

const toggleDrawer = () => {
    const drawerOpened = drawer.style.left < '0px' ? false : true;

    drawer.style.left = drawerOpened ? '-250px' : '0';
    main.style.marginLeft = drawerOpened ? '0' : '250px';
}

toggleButton.addEventListener('click', toggleDrawer);

// BOTÃO CONTATO
document.getElementById('btn-contato').addEventListener('click', function() {
    var contactSection = document.getElementById('contactSection');
    var contactSectionY = contactSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: contactSectionY - 50, 
        behavior: 'smooth' 
    });
}); 

//drawer botoes
 
document.getElementById('desktop-btn').addEventListener('click', function() {
    var desktop = document.getElementById('menu-desktop');
    var main = document.querySelector('main');

    var sobreSection = document.querySelector('.sessao-sobre');
    var sobreSectionY = sobreSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: sobreSectionY - 180, 
        behavior: 'smooth' 
    });
});



document.getElementById('desktop-btn2').addEventListener('click', function() {
    var desktop = document.getElementById('menu-desktop');
    var main = document.querySelector('main');
    
    var parceriasSection = document.querySelector('.parcerias');
    var parceriasSectionY = parceriasSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: parceriasSectionY - 10, 
        behavior: 'smooth' 
    });
});

document.getElementById('desktop-btn3').addEventListener('click', function() {
    var desktop = document.getElementById('menu-desktop');
    var main = document.querySelector('main');
    
    var aulasSection = document.querySelector('.sessao-aula');
    var aulasSectionY = aulasSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: aulasSectionY - 100, 
        behavior: 'smooth' 
    });
});




document.getElementById('drawer-btn').addEventListener('click', function() {
    var drawer = document.getElementById('drawer');
    var main = document.querySelector('main');
    const drawerOpened = drawer.style.left >= '0px';
    drawer.style.left = drawerOpened ? '-250px' : '0';
    main.style.marginLeft = drawerOpened ? '0' : '250px';
    
    var sobreSection = document.querySelector('.sessao-sobre');
    var sobreSectionY = sobreSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: sobreSectionY - 180, 
        behavior: 'smooth' 
    });
});



document.getElementById('drawer-btn2').addEventListener('click', function() {
    var drawer = document.getElementById('drawer');
    var main = document.querySelector('main');
    const drawerOpened = drawer.style.left >= '0px';
    drawer.style.left = drawerOpened ? '-250px' : '0';
    main.style.marginLeft = drawerOpened ? '0' : '250px';
    
    var parceriasSection = document.querySelector('.parcerias');
    var parceriasSectionY = parceriasSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: parceriasSectionY - 0, 
        behavior: 'smooth' 
    });
});

document.getElementById('drawer-btn3').addEventListener('click', function() {
    var drawer = document.getElementById('drawer');
    var main = document.querySelector('main');
    const drawerOpened = drawer.style.left >= '0px';
    drawer.style.left = drawerOpened ? '-250px' : '0';
    main.style.marginLeft = drawerOpened ? '0' : '250px';
    
    var aulasSection = document.querySelector('.sessao-aula');
    var aulasSectionY = aulasSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: aulasSectionY - 10, 
        behavior: 'smooth' 
    });
});


document.getElementById('drawer-btn4').addEventListener('click', function() {
    var drawer = document.getElementById('drawer');
    var main = document.querySelector('main');
    const drawerOpened = drawer.style.left >= '0px';
    drawer.style.left = drawerOpened ? '-250px' : '0';
    main.style.marginLeft = drawerOpened ? '0' : '250px';

    var contatoSection = document.querySelector('sessao-contato');
    var contatoSectionY = contatoSection.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
        top: contatoSectionY - 20, 
        behavior: 'smooth' 
    });
}); 




// SLIDER 

let cont = 1;


document.getElementById('radio1').checked = true;

setInterval(() => {
    proximaImg();
}, 5000);

function proximaImg() {
    cont++;
    if (cont > 4) {
        cont = 1;
    }
    document.getElementById('radio' + cont).checked = true;
}


/*ENVIO DE FORMULARIO PARA O EMAIL*/ 
class FormSubmit {
    constructor(settings) {
        this.settings = settings;
        this.form = document.querySelector(settings.form);
        this.formButton = document.querySelector(settings.button);
        if (this.form) {
            this.url = this.form.getAttribute("action");
        }
        this.sendForm = this.sendForm.bind(this);
    }

    displaySuccess() {
        this.form.innerHTML = this.settings.success;
    }

    displayError() {
        this.form.innerHTML = this.settings.error;
    }

    getFormObject() {
        const formObject = {};
        const fields = this.form.querySelectorAll("[name]");
        fields.forEach((field) => {
            formObject[field.getAttribute("name")] = field.value;
        });
        return formObject;
    }

    onSubmission(event) {
        event.preventDefault();
        event.target.disabled = true;
        event.target.innerText = "Enviando...";
    }

    async sendForm(event) {
        try {
            this.onSubmission(event);
            await fetch(this.url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                },
                body: JSON.stringify(this.getFormObject()),
            });
            this.displaySuccess();
        } catch (error) {
            this.displayError();
            throw new Error(error);
        }
    }

    init() {
        if (this.form) this.formButton.addEventListener("click", this.sendForm);
        return this;
    }
}

const formSubmit = new FormSubmit({
    form: "[data-form]",
    button: "[data-button]",
    success: "<h1>Formulário enviado com sucesso!</h1>",
    error: "<h1>Erro ao enviar o formulário!</h1>"
});

formSubmit.init();
